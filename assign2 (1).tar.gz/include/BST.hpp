#include <algorithm>
#include <iostream>
#include <vector>
#include <functional>
#include <iterator>
#include <memory>


template <typename T>
class TreeNode
{
    public:
        T element;
        std::unique_ptr<TreeNode<T>> left;
        std::unique_ptr<TreeNode<T>> right;

        TreeNode<T>(const T& e)
            :element{e}, left{nullptr}, right{nullptr} {}

        ~TreeNode() {}

};


template <typename T>
struct BST
{
    public:
        std::unique_ptr<TreeNode<T>> root = nullptr;

        ~BST() {}

        bool insert(const T& key);
        bool search(const T& key);
        bool remove(const T& key);

    private:
        bool insert(std::unique_ptr<TreeNode<T>>& t, const T& key);
        bool search(std::unique_ptr<TreeNode<T>>& t, const T& key);
        bool remove(std::unique_ptr<TreeNode<T>>& t, const T& key);

        T find_rightmost_key(std::unique_ptr<TreeNode<T>>& t);
};

template <typename T>
bool BST<T>::insert(const T& key) {
    return insert(root, key);
}

template <typename T>
bool BST<T>::search(const T& key) {
    return search(root, key);
}

template <typename T>
bool BST<T>::remove(const T& key) {
    return remove(root, key);
}

template <typename T>
bool BST<T>::insert(std::unique_ptr<TreeNode<T>>& t, const T& key) {

    // TODO
    // if insertion fails (i.e. if the key already exists in tree), return false
    // otherwise, return true

    // reference : Cheon in guk, Choi yeong gyu, "DATA STRUCTURES USING C++", 2016, saengneung, pp.350-361.
    // reference : https://github.com/TheAlgorithms/C-Plus-Plus/blob/master/data_structures/binary_search_tree2.cpp
    //'root' is poiniter to the root, default is nullptr.
     
    if (root == t && root == nullptr) {
        root = std::unique_ptr<TreeNode<T>>(new TreeNode<T>(key));
        return true;
    }
    
    
    if (key < t->element) {//if key < root(t->element)
        if (t->left == nullptr) {//go left, and if there is no left children node, key is left children 
            t->left = std::unique_ptr<TreeNode<T>>(new TreeNode<T>(key));
            return true;
        } else {
            return insert(t->left,key);
        }
    } else if (key > t->element) {
        if (t->right == nullptr) {//go left, and if there is no left children node, key is left children 
            t->right = std::unique_ptr<TreeNode<T>>(new TreeNode<T>(key));
            return true;
        } else {
            return insert(t->right,key); 
            }
    } else {
        return false;
    }
}

template <typename T>
bool BST<T>::search(std::unique_ptr<TreeNode<T>>& t, const T& key) {

    // TODO

    // reference : Cheon in guk, Choi yeong gyu, "DATA STRUCTURES USING C++", 2016, saengneung, pp.350-361.
    // if I find value, return the pointer of the node of that value
    // if key exists in tree, return true
    // otherwise, return false

    if (t == nullptr) {
        return false;
    } //if there is not node, return false
    
    if (key < t->element) {
        return search(t->left,key);
    } else if (key > t->element) {
        return search(t->right,key);
    } else {
        return true;
    }

}

template <typename T>
T BST<T>::find_rightmost_key(std::unique_ptr<TreeNode<T>>& t) {
    // TODO
    
    if (t->right == nullptr) {
        return t->element;
        }
    return find_rightmost_key(t->right);
    }


template <typename T>
bool BST<T>::remove(std::unique_ptr<TreeNode<T>>& t, const T& key) {
    // TODO
    // if key does not exist in tree, return false
    // otherwise, return true
    

    //case4 is not in a tree -> do nothing, return false/
    if (t == nullptr) {
        return false;
    }
    //searching t
    if (key < t->element) {
        return remove(t->left,key);
        
    } else if (key > t->element) {
        return remove(t->right,key);
        
    } else {//key==t->element
        //case1. no child node, just delete.
        if (t->left==nullptr && t->right==nullptr) {    
            t.reset();    
        } 
        //case2. just 1 child node : if there is just one node, just transfer of ownership by using std::move function
        else if(t->left && t->right == nullptr) {
            t = std::move(t->left); 
        } 
        else if(t->left == nullptr && t->right) {
            t = std::move(t->right); 
        }
        //case3
        /*For all nodes to the left of the node you wish to delete,
        so we first find the max element from its left subtree (let us call it as L_subtree). 
        and just change the value.*/
        else {
            T tempvalue = find_rightmost_key(t->left);
            remove(t->left, tempvalue);
            t->element = tempvalue;
        }
        return true;
    }
}