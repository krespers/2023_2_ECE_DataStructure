## Examples

### Graphviz formatter

#### Quick start

```sh
$ ./graphviz-formatter > rbtree.dot
$ dot -Tpng rbtree.dot -o rbtree.png
```
