#include <string>

#include "deque.hpp"

template<typename Deque>
class Palindrome {
public:
    bool is_palindrome(const std::string&);
    void reset_deque();

private:
    Deque deque;
};

template<typename Deque>
bool Palindrome<Deque>::is_palindrome(const std::string& s1) {
    // TODO
    std::string palindromestring;
    for (char c : s1) {
        palindromestring += c;
    }
    for (char c : palindromestring) {
        deque.push_front(c);
    }
    
    // Put it in the deque and compare the front and back values ​​one by one. 
    // If even one of them is different, it is not a palindrome.
    while (deque.size() > 1) {
    if (deque.remove_front() != deque.remove_back()) {
        reset_deque();
        return false;
        }
    }
    reset_deque();
    return true;
}

template<typename Deque>
void Palindrome<Deque>::reset_deque() {
    while (!deque.empty())
        deque.remove_front();
}
