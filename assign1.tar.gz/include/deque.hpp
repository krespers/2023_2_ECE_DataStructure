#ifndef _DEQUE_H
#define _DEQUE_H

#include <string>
#include <iostream>
#include <type_traits>
#include <optional>
#include <iostream>
#include <memory>
#include <cassert>

/* NOTE: Deque, ArrayDeque, ListDeque Declaration modification is not allowed.
 * Fill in the TODO sections in the following code. */
template <typename T>
class Deque {
public:
    virtual ~Deque() = default;

    /* NOTE: We won't implement push functions that take rvalue references. */
    virtual void push_front(const T&) = 0;
    virtual void push_back(const T&) = 0;

    /* NOTE: Unlike STL implementations which have separate `front` and
       pop_front` functions, we have one unified method for removing an elem. */
    virtual std::optional<T> remove_front() = 0;
    virtual std::optional<T> remove_back() = 0;

    virtual bool empty() = 0;
    virtual size_t size() = 0;

    virtual T& operator[](size_t) = 0;
};

template <typename T>
class ArrayDeque : public Deque<T> {
public:
    ArrayDeque();
    ~ArrayDeque() = default;

    void push_front(const T&) override;
    void push_back(const T&) override;

    std::optional<T> remove_front() override;
    std::optional<T> remove_back() override;

    bool empty() override;
    size_t size() override;
    size_t capacity();

    T& operator[](size_t) override;

private:
    std::unique_ptr<T[]> arr;
    size_t front;
    size_t back;
    size_t size_;
    size_t capacity_;

    void resize();
};

template <typename T>
ArrayDeque<T>::ArrayDeque() :
    front{0},
    back{0},
    size_{0}, capacity_{64} {
    arr = std::make_unique<T[]>(capacity_);
}

    // reference : Cheon in guk, Choi yeong gyu, "DATA STRUCTURES USING C++", 2016, saengneung, pp.152-153.

template <typename T>
void ArrayDeque<T>::push_front(const T& item) {
    if (size_ == capacity_) {
        resize();//if array is full, resize
    }

    //front index. front starts from arr[63], and using modular 
    front = (front + capacity_ -1) % capacity_;
    arr[front] = item;
    size_++;
    // TODO
    
}

template <typename T>
void ArrayDeque<T>::push_back(const T& item) {
    if (size_ == capacity_) {
        resize();//if array is full, resize
    }

    //back index. back starts from arr[0], and using modular 
    arr[back] = item;
    back = (back + 1) % capacity_;
    size_++;
    // TODO
    
}

template <typename T>
std::optional<T> ArrayDeque<T>::remove_front() {
    // TODO
    if (empty()) {
        return std::nullopt;
    //if deque is empty, return nullopt
    }
    T value = arr[front];
    front = (front + 1) % capacity_; //similar to push_back()
    size_--;
    return value;
    //I didn't used arr[back].~T() because this function have to return value.
}

template <typename T>
std::optional<T> ArrayDeque<T>::remove_back() {
    // TODO
    if (empty()) {
        return std::nullopt;
    //if deque is empty, return nullopt
    }
    back = (back + capacity_ - 1) % capacity_; //similar to push_front()
    T value = arr[back];
    size_--;
    return value;
}

template <typename T>
void ArrayDeque<T>::resize() {
    // TODO
    size_t new_capacity_ = capacity_ * 2;
    std::unique_ptr<T[]> new_arr = std::make_unique<T[]>(new_capacity_);

    //copy array by using for loop
    for (size_t i=0; i < size_ ; i++) {
        new_arr[i]=arr[(front + i)% capacity_];
    }

    arr = std::move(new_arr);
    front = 0;
    back = size_;
    capacity_ = new_capacity_;

}

template <typename T>
bool ArrayDeque<T>::empty() {
    return size_ == 0;
}

template <typename T>
size_t ArrayDeque<T>::size() {
    return size_;
    
}

template <typename T>
size_t ArrayDeque<T>::capacity() {
    // TODO
    return capacity_;
}

template <typename T>
T& ArrayDeque<T>::operator[](size_t idx) {
    // TODO
    if (idx < size_) {
        return arr[(front + idx)% capacity_];
    }
    else {
        throw std::out_of_range("out of range");
    }

    
}

template<typename T>
struct ListNode {
    std::optional<T> value;
    ListNode* prev;
    ListNode* next;

    ListNode() : value(std::nullopt), prev(this), next(this) {}
    ListNode(const T& t) : value(t), prev(this), next(this) {}

    ListNode(const ListNode&) = delete;
};

template<typename T>
class ListDeque : public Deque<T> {
public:
    ListDeque();
    ~ListDeque();

    void push_front(const T&) override;
    void push_back(const T&) override;

    std::optional<T> remove_front() override;
    std::optional<T> remove_back() override;

    bool empty() override;
    size_t size() override;

    T& operator[](size_t) override;

    size_t size_ = 0;
    ListNode<T>* sentinel = nullptr;
};

template<typename T>
ListDeque<T>::ListDeque() : sentinel(new ListNode<T>{}), size_(0) {}

    // reference : HOROWITZ, SAHNI, MEHTA, "c++ data structure 2nd edition", Translated by Seokho Lee, 2007, INFINITY BOOKS, pp.199-201.
    // reference : Cheon in guk, Choi yeong gyu, "DATA STRUCTURES USING C++", 2016, saengneung, pp.242-243.

template<typename T>
void ListDeque<T>::push_front(const T& t) {
    // TODO
    // When the current node is sentinel, the "preceding node" of the newNode is set as the current node (sentinel).
    // Set successor node of the newNode is set as the the successor node of the current node (sentinel).
    // Set the predecessor node of the successor node of the Sentinel node((sentinel->next)'s prev) is newNode
    // Set the successor node of the sentinel node to newNode
    ListNode<T>* newNode = new ListNode<T>(t);
    newNode->prev = sentinel;
    newNode->next = sentinel->next;
    sentinel->next->prev = newNode;
    sentinel->next = newNode;
    size_++;
}

template<typename T>
void ListDeque<T>::push_back(const T& t) {
    // TODO
    // Write the code in the same way as above (push_front).
    ListNode<T>* newNode = new ListNode<T>(t);
    newNode->prev = sentinel->prev;
    newNode->next = sentinel;
    sentinel->prev->next = newNode;
    sentinel->prev = newNode;
    size_++;
}

template<typename T>
std::optional<T> ListDeque<T>::remove_front() {
    // TODO
    if (empty()){
        return std::nullopt;
    }
    // When the current node is sentinel, 
    // modify the connection pointer between the sentinel node and the node following the frontnode.
    // and delete front node
    ListNode<T>* frontNode = sentinel->next;
    T value = frontNode->value.value();
    frontNode->next->prev = sentinel;
    sentinel->next = frontNode->next;
    delete frontNode;
    size_--;
    return value;
}

template<typename T>
std::optional<T> ListDeque<T>::remove_back() {
    // TODO
    // Write the code in the same way as above (remove_front).
    if (empty()) {
        return std::nullopt;
    }
    ListNode<T>* backNode = sentinel->prev;
    T value = backNode->value.value();
    backNode->prev->next = sentinel;
    sentinel->prev = backNode->prev;
    delete backNode;
    size_--;
    return value;
}

template<typename T>
bool ListDeque<T>::empty() {
    // TODO
    return size_ == 0;
}

template<typename T>
size_t ListDeque<T>::size() {
    // TODO
    return size_;
}

template<typename T>
T& ListDeque<T>::operator[](size_t idx) {
    // TODO
    if (idx >= size_) {
        throw std::out_of_range("out of range");
    }
    ListNode<T>* currentNode = sentinel->next;
    for (size_t i = 0 ; i<idx ; i++) {
        currentNode = currentNode->next;
    }
    return currentNode->value.value();
    
}

template<typename T>
std::ostream& operator<<(std::ostream& os, const ListNode<T>& n) {
    if (n.value)
        os << n.value.value();

    return os;
}

template<typename T>
std::ostream& operator<<(std::ostream& os, const ListDeque<T>& l) {
    auto np = l.sentinel->next;
    while (np != l.sentinel) {
        os << *np << ' ';
        np = np->next;
    }

    return os;
}

template<typename T>
ListDeque<T>::~ListDeque() {
    // TODO
    while (!empty()) {
        remove_front();
    }
    delete sentinel;
}

#endif // _DEQUE_H
