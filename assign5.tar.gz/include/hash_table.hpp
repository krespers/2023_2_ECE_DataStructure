#include <algorithm>
#include <iostream>
#include <vector>
#include <functional>
#include <iterator>
#include <memory>

#define INITIAL_TABLE_SIZE 64

#include "hash_slot.hpp"
#include "hash_funcs.hpp"

template <typename K, typename V>
class HashTable {
public:
    HashTable(HashFunc *hash_func);
    ~HashTable();
    int get(const K &key, V &value);
    int put(const K &key, const V &value);
    int remove(const K &key);
    size_t get_table_size();
    size_t get_size();
    double get_load_factor();

protected:
    size_t table_size;
    
private:
    HashFunc *hash_func;
    size_t size;
    HashSlot<K, V> *table;

    // Should be overriden by the derived class
    virtual unsigned long get_next_pos(unsigned long pos,
                                       unsigned long step) = 0;
    unsigned long get_pos(const K key);
    void enlarge_table();
};

template <typename K, typename V>
HashTable<K, V>::HashTable(HashFunc *hash_func): table(), hash_func(hash_func),
                                                 size(0), table_size(INITIAL_TABLE_SIZE) {
    table = new HashSlot<K, V>[table_size];
}

template <typename K, typename V>
HashTable<K, V>::~HashTable() {
    delete[] table;
}

template <typename K, typename V>
void HashTable<K, V>::enlarge_table() {
    // TODO
/*
Our hash table requires that its table size is
 doubled if its load factor is greater than 0.5. 
You will need to implement such a dynamic grow feature
 in this HashTable::enlarge_table() function.
*/
    //size doubling !!!!!!!!!!!!!!!!
    table_size = table_size * 2;
    HashSlot<K,V> *removing_table = table;// Store the pointer to the old table
    table = new HashSlot<K,V>[table_size];// Allocate a new table with the doubled size
    size = 0; // If I do not enter this code, it will not work when compiling after an error occurs.

    //re-hashing!!!!!!!
    for (size_t i = 0 ; i < (table_size / 2) ; ++i) {
        if (!removing_table[i].is_empty() && !removing_table[i].is_removed()) {
            put(removing_table[i].get_key(), removing_table[i].get_value());
        }
    }
    delete[] removing_table;// Deallocate the memory of the old table
}

template <typename K, typename V>
unsigned long HashTable<K, V>::get_pos(const K key) {
    // TODO
    // This returns the initial position index for key within the base array. 
    // If the provided hash function is hash() and the table size is M, its return value would be hash(key) % M.
    return (hash_func->hash(key)) % table_size;
}

template <typename K, typename V>
int HashTable<K, V>::get(const K &key, V &value) {
    // TODO

    //It first identifies the slot with key, and returns the value within the key through the reference parameter value.
    // It returns -1 if it failed to find the slot with key. Otherwise, it returns the number of probes that have been performed 
    //to locate the corresponding slot (which has the same key).

    //find !!!! //It first identifies the slot with key, 
    for (size_t i = 1 ; i < this->table_size ; ++i) {
        size_t pos = this->get_next_pos(this->get_pos(key),i-1);

    //removed => pass!!! 
        if(this->table[pos].is_removed()) {
            continue;
        }
    //empty => return -1 !!!
        if(this->table[pos].is_empty()) {
            return -1;
        }
    //key = find!!! =>
        if(this->table[pos].get_key() == key) {
        value = this->table[pos].get_value();
        return i; //Otherwise, it returns the number of probes that have been performed 
        }
    }
    return -1;// It returns -1 if it failed to find the slot with key. 
}

    /*
    It stores the pair key and value into the hash table. It returns -1 1) if it failed to insert or 
    2) if the same key already exists in the hash table. Othewrise, it returns the number of probes that have been preformed to locate the corresponding slot (which has the same key). 
    Note that if you had to enlarge the table, put() returns the number of probes that have been performed before enlarging the table.
    */
template <typename K, typename V>
int HashTable<K, V>::put(const K &key, const V &value) {
    // TODO
    for (size_t i = 1 ; i < this->table_size ; ++i) {
        //pos = get_next_pos(get_pos,i);
        size_t pos = this->get_next_pos(this->get_pos(key),i-1);

        //removed => pass!!!
        if(this->table[pos].is_removed()) {
            continue;
        }
        //key = find!!! =>
        if(this->table[pos].is_empty()) {
            this->size++;
            this->table[pos].set_key_value(key,value);

            if(get_load_factor() > 0.5) {
                enlarge_table();
                return i;
            }//Note that if you had to enlarge the table, 
            return i; //put() returns the number of probes 
        } else if (this->table[pos].get_key() == key) {
            return -1;//2) if the same key already exists in the hash table. 
        }
    }
    return -1;//It returns -1 1) if it failed to insert
}
    


template <typename K, typename V>
int HashTable<K, V>::remove(const K &key) {
    // TODO
    for (size_t i = 1 ; i < this->table_size ; ++i) {
        size_t pos = get_next_pos(get_pos(key),i-1);

        //removed => pass!!
        if(this->table[pos].is_removed()) {
            continue;
        } else if (this->table[pos].is_empty()) {
            return -1;
        } else if (this->table[pos].get_key() == key) {
            this->table[pos].set_removed();
            this->size--;
            return i;
        }
    }    
    return -1;//fail!
}

template <typename K, typename V>
size_t HashTable<K, V>::get_table_size() {
    return table_size;
}

template <typename K, typename V>
size_t HashTable<K, V>::get_size() {
    return size;
}

template <typename K, typename V>
double HashTable<K, V>::get_load_factor() {
    return (double)size/table_size;
}


template <typename K, typename V>
class LinearProbeHashTable: public HashTable<K, V> {
public:
    LinearProbeHashTable(HashFunc *hash_func): HashTable<K, V>(hash_func) {
    }
    
private:
    virtual unsigned long get_next_pos(unsigned long pos, unsigned long step) {
        // TODO
        //position(k, M, i) = (hash(k) + i) % M
        return ((pos + step)) % ((this->get_table_size()));
    }
};

template <typename K, typename V>
class QuadProbeHashTable: public HashTable<K, V> {
public:
    QuadProbeHashTable(HashFunc *hash_func): HashTable<K, V>(hash_func) {
    }
private:
    virtual unsigned long get_next_pos(unsigned long pos, unsigned long step) {
        // TODO
        //https://stackoverflow.com/questions/2348187/moving-from-linear-probing-to-quadratic-probing-hash-collisons?rq=4
        // position(k, M, i) = (hash(k) + 0.5*i + 0.5*i*i) % M
        //Quad probing is calculating by adding +1, +4, and +9 to the fixed- beginning digits!
        /*
        in the hashtable_test.cpp
        
        this return (pos + (step + step*step)/2) % (this->get_table_size()); code <<< meaningless code.... bugs??????
        */

        return (pos + (step + step*step)/2) % (this->get_table_size());
    }
};