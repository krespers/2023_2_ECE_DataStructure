#ifndef __DIJKSTRA_SHORTEST_PATHS_H_
#define __DIJKSTRA_SHORTEST_PATHS_H_

#include <unordered_map>
#include <optional>
#include <tuple>
#include <queue>
/* Feel free to add more standard library headers */

#include "graph.hpp"

/* Given a vertex `v`, `dijkstra_shortest_path` is:
 * - `nullopt` if `v` is not reachable from `src`.
 * - {`u`, `d`} where `u` is the predecessor of `v` and `d` is the distance
 *   from `src`
 */

//reference : https://korini.tistory.com/23
std::unordered_map<vertex_t, std::optional<std::tuple<vertex_t, edge_weight_t>>>
dijkstra_shortest_path(Graph& g, vertex_t src) {
    std::unordered_map<vertex_t, std::optional<std::tuple<vertex_t, edge_weight_t>>> result;
    for (vertex_t v = 0; v < g.getnum_vertices(); ++v) {
        result[v] = std::nullopt;
    }
    std::vector<edge_weight_t> dist(g.getnum_vertices(), std::numeric_limits<edge_weight_t>::max());
    typedef std::tuple<edge_weight_t, vertex_t> pq_node;
	// Create a min heap priority queue to process vertices with the smallest distances first.
    std::priority_queue<pq_node, std::vector<pq_node>, std::greater<pq_node>> priorityqueue;
	// Set the distance of the source vertex to itself to 0 and push it to the priority queue.
    dist[src] = 0;
    priorityqueue.push({dist[src], src});
    result[src] = {-1, dist[src]};// Process vertices until the priority queue is empty.
 	// Extract the vertex with the smallest distance from the priority queue.
    while (!priorityqueue.empty()) {
        auto [d, x] = priorityqueue.top();
        priorityqueue.pop();
 	// Skip processing if the current distance is greater than the stored distance for the vertex.
        if (d < dist[x]) {
            continue;
        }
	// Explore neighbors of the current vertex and update their distances if a shorter path is found.
        for (const auto& e : g.adjacencylist(x)) {
            auto [from, to, weight] = e;

            if (dist[to] > d + weight) {
                dist[to] = d + weight;
                priorityqueue.push({dist[to], to});
                result[to] = {x, dist[to]};
            }
        }
    }// Return the final result map containing the shortest paths from src to each vertex.
    return result;
}

#endif // __DIJKSTRA_SHORTEST_PATHS_H_
