#ifndef __PRIM_MINIMUM_SPANNING_TREE_H_
#define __PRIM_MINIMUM_SPANNING_TREE_H_

#include <optional>
#include <vector>
#include <tuple>
#include <queue>
/* Feel free to add more standard library headers */

/* Returns the vector of edges in the MST, or std::nullopt if MST does
 * not exist */

//reference : https://4legs-study.tistory.com/112
std::optional<edges_t> prim_minimum_spanning_tree(Graph& g, vertex_t src) {
    std::vector<bool> visitcheck(g.getnum_vertices(), false);
    edges_t MST;//create empty vector to store the edges of MST
    using pq_node = std::tuple<edge_weight_t, vertex_t, vertex_t>;//Defines the priority queue
    std::priority_queue<pq_node, std::vector<pq_node>, std::greater<pq_node>> priorityqueue;//Creates a priority queue pq that stores pq_node elements in ascending order of edge weights (min heap).
    
	auto addedge = [&](vertex_t vertex) {
        for (const auto& e : g.adjacencylist(vertex)) {
            auto [from, to, weight] = e;
            priorityqueue.push({weight, from, to});
        }
    };	//Defines a lambda function 

    visitcheck[src] = true;
    addedge(src);

    while (!priorityqueue.empty()) {
        auto [weight, from, to] = priorityqueue.top();
        priorityqueue.pop();

        if (visitcheck[to]) {
            continue;
        }

        MST.push_back({from, to, weight});
        visitcheck[to] = true;
        addedge(to);
    }

    if (MST.size() == g.getnum_vertices() - 1) {
        return MST;
	} else {    
		return std::nullopt;
	}
}
#endif // __PRIM_MINIMUM_SPANNING_TREE_H_
