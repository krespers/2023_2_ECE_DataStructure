#ifndef __TOPOLOGICAL_SORT_H_
#define __TOPOLOGICAL_SORT_H_

#include <vector>
#include <queue>//for Kahn's algorithm
#include "graph.hpp"
//#include <iostream> // For debugging
/* Feel free to add more standard library headers */


//reference : https://m42-orion.tistory.com/65
/* Return a valid topologically sorted sequence of vertex descriptors using Kahn's algorithm */
std::vector<vertex_t> topological_sort(Graph& g) {
    std::vector<vertex_t> result; // Vector to store the final sorted sequence of vertices
    std::vector<int> indegree(g.getnum_vertices(), 0); // Array to represent the indegree of each vertex
    std::queue<vertex_t> indegreequeue; // Queue to process vertices with indegree 0

    // Calculate indegree for each vertex
    for (vertex_t v = 0 ; v < g.getnum_vertices(); ++v) {
        for (const auto& e : g.adjacencylist(v)) {
            auto [from, to, weight] = e;
            indegree[to]++;
        }
    }

    // Add vertices with indegree 0 to the queue
    for (vertex_t v = 0; v < g.getnum_vertices(); ++v) {
        if (indegree[v] == 0) {// && !g.adj_list(v).empty() <= This condition was also added before changing test case 8->6.
            indegreequeue.push(v);
        }
    }

    // Kahn's algorithm
    while (!indegreequeue.empty()) {
        vertex_t current = indegreequeue.front();
        indegreequeue.pop();
        result.push_back(current);

        // Update indegree and enqueue adjacent vertices
        for (const auto& e : g.adjacencylist(current)) {
            auto [from, to, weight] = e;
            indegree[to]--;

            // Enqueue vertices with updated indegree of 0
            if (indegree[to] == 0) {
                indegreequeue.push(to);
            }
        }
    }
    //if graph contains cycle, the result may not include all vertices....

    return result;
}

#endif // __TOPOLOGICAL_SORT_H_